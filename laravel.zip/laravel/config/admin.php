<?php

return [
    'paginate' => 10,
    'noImage' => 'img/no-image.png',
    'listCategory' => 'list Category'
];