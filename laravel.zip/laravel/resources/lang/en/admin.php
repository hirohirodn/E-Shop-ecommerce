<?php

return [
	'dashboard' => 'Dashboard',
    'profile' => 'Profile',
    'listUser' => 'List User',
    'Category' => 'Category',
    'Brand' => 'Brand',
    'listCategory' => 'List Category',
    'listBrand' => 'List Brand',
    'listProduct'=>'List Product',
    'detailProduct'=> 'Detail Product'
];