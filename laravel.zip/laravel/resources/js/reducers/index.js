import { combineReducers } from "redux";
import getUser from "./getUser";
// import visibilityFilter from "./visibilityFilter";

export default combineReducers({
    getUser
});
