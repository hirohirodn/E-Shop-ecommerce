<?php $__env->startSection('content'); ?>

        <div class="col-md-8">
            <div class="card">
                

                <div class="card-header"><h3>Add Product</h3></div>
                <br>
                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                
                <?php if(Session('success')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong><?php echo e(Session('success')); ?></strong>
                    </div>
                <?php endif; ?>
                <?php if(Session('error_file') || Session('enterSale')): ?>
                    <div class="alert alert-danger alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong><?php echo e(Session('error_file')); ?></strong>
                            <strong><?php echo e(Session('enterSale')); ?></strong>
                    </div>
                <?php endif; ?>

                <div class="card-body">
                    <form id="main-contact-form" class="contact-form row" name="contact-form" enctype="multipart/form-data" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group col-md-12">
                            <select name="id_category">
                                <option value="">Please select category</option>
                                <?php $__currentLoopData = $getCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category['id']); ?>"><?php echo e($category['category']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-md-12">
                            <select name="id_brand">
                                <option value="">Please select brand</option>
                                <?php $__currentLoopData = $getBrand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($brand['id']); ?>"><?php echo e($brand['brand']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-md-12">
                            <input type="text" name="name" class="form-control" placeholder="Name" value="<?php echo e(!empty(old('name')) ? old('name') : ''); ?>">
                        </div>
                        <div class="form-group col-md-12">
                            <input type="file" name="image[]" class="form-control" multiple>
                        </div>
                        <div class="form-group col-md-12">
                            <input type="text" name="web_id" class="form-control" placeholder="Web_id" value="<?php echo e(!empty(old('web_id')) ? old('web_id') : ''); ?>">
                        </div>
                        <div class="form-group col-md-12">
                            <input type="text" class="form-control" id="display" value="<?php echo e(!empty(old('price')) ? old('price') : ''); ?>" placeholder="Price">
                            <input type="number" hidden="" id="price" name="price" value="">
                        </div>
                        <div class="form-group col-md-3">
                            Status of product
                        </div>
                        <div class="form-group col-md-9">
                            <div class="form-group col-md-12">
                                <input type="radio" id="new" name="status" value="0" checked=""> New
                            </div>
                            <div class="form-group col-md-12">
                                <input type="radio" id="sale" name="status" value="1"> Sale
                                <input type="text" id="value_sale" name="sale" value="" disabled="">%
                            </div>
                        </div>
                        <div class="form-group col-md-12">
                            <input name="condition" id="condition" class="form-control" placeholder="Condition" value="<?php echo e(!empty(old('condition')) ? old('condition') : ''); ?>"></input>
                        </div>
                        <div class="form-group col-md-12">
                            <textarea name="detail" id="detail" class="form-control" placeholder="Detail"></textarea>
                        </div>
                        <div class="form-group col-md-12">
                            <textarea name="company_profile" id="company_profile" class="form-control" placeholder="Company_profile"></textarea>
                        </div>                                                 
                        <div class="form-group col-md-12">
                            <input type="submit" name="submit" class="btn btn-primary pull-right" value="Submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script type="text/javascript">
            document.getElementById("display").onblur =function (){    
                this.value = parseFloat(this.value.replace(/,/g, ""))
                                .toFixed()
                                .toString()
                                .replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                
                document.getElementById("price").value = this.value.replace(/,/g, "")
                
            }

           $('#sale').click(function()
            {
              $('#value_sale').removeAttr("disabled");
            });

            $('#new').click(function()
            {
              $('#value_sale').attr("disabled","disabled");
            });
            
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/baovic/Desktop/www/reactjs-laravel/laravel/laravel/resources/views/frontend/product/product.blade.php ENDPATH**/ ?>