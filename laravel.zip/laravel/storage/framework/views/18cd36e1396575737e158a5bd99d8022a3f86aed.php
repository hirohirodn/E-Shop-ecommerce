<?php $__env->startSection('content'); ?>

    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Register Member')); ?></div>

                <div class="card-body">
                    <?php if(session('success')): ?>
                            <div class="alert alert-success alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                <h4><i class="icon fa fa-check"></i> Thông báo!</h4>
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <br>
                    <form method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Full Name (*)')); ?></label>

                            <div class="col-md-8">
                                <input 
                                    id="name" 
                                    type="text" 
                                    class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                                    name="name" 
                                    value="<?php echo e($getUser['name']); ?>" 
                                    autocomplete="name" 
                                    autofocus
                                >
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Email (*)')); ?></label>

                            <div class="col-md-8">
                                <input 
                                readonly 
                                    id="name" 
                                    type="text" 
                                    class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                                    name="email" 
                                    value="<?php echo e($getUser['email']); ?>" 
                                    autocomplete="email" 
                                    autofocus
                                >
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password (*)')); ?></label>

                            <div class="col-md-8">
                                <input 
                                    id="name" 
                                    type="password" 
                                    class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                                    name="password" 
                                    value="<?php echo e(old('password')); ?>" 
                                    autocomplete="password" 
                                    autofocus
                                >
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Phone')); ?></label>

                            <div class="col-md-8">
                                <input 
                                    id="phone" 
                                    type="text" 
                                    class="form-control <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                                    name="phone" 
                                    value="<?php echo e($getUser['phone']); ?>" 
                                    autocomplete="phone" 
                                    autofocus
                                >
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Address')); ?></label>

                            <div class="col-md-8">
                                <input 
                                    id="address" 
                                    type="text" 
                                    class="form-control <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                                    name="address" 
                                    value="<?php echo e($getUser['address']); ?>" 
                                    autocomplete="address" 
                                    autofocus
                                >
                            </div>
                        </div>
                       
                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Avatar (*)')); ?></label>

                            <div class="col-md-8">
                                <input 
                                    id="avatar" 
                                    type="file" 
                                    class="form-control <?php if ($errors->has('avatar')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('avatar'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                                    name="avatar"    
                                >
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Country (*)')); ?></label>

                            <div class="col-md-8">
                                <select name="country" class="form-control form-control-line">
                                        <option value="">Please select</option>


                                        <?php $__currentLoopData = $getCountry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            <?php if(!empty($getUser['country']) && $value['id'] == $getUser['country']) echo "selected"?>     value="<?php echo e($value['id']); ?>"
                                        >
                                            <?php echo e($value['name']); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                            </div>
                        </div>


                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Register')); ?>

                                </button>

                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/baovic/Desktop/www/reactjs-laravel/laravel/laravel/resources/views/frontend/member/profile.blade.php ENDPATH**/ ?>