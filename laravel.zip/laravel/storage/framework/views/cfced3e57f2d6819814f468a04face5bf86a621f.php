<?php $__env->startSection('content'); ?>
 
	<div class="container-fluid">
        <div class="product-details"><!--product-details-->
            
                <div class="product-information" style="padding-left: 0;"><!--/product-information-->
                    <div class="contact-form">
                        <h2 class="title text-center">Product Information</h2>
                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if(Session('AtLeast') || Session('TooMuch') || Session('enterSale')): ?>
                            <div class="alert alert-danger alert-block">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo e(Session('AtLeast')); ?></strong>
                                    <strong><?php echo e(Session('TooMuch')); ?></strong>
                                    <strong><?php echo e(Session('enterSale')); ?></strong>
                            </div>
                        <?php endif; ?>
                        <?php if(Session('updated')): ?>
                            <div class="alert alert-success alert-block">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo e(Session('updated')); ?></strong>
                            </div>
                        <?php endif; ?>
                        <form id="main-contact-form" class="contact-form row" name="contact-form" enctype="multipart/form-data" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="col-md-2">
                                <label>Name</label>
                            </div>
                            <div class="form-group col-md-10">
                                <input type="text" class="form-control" name="name" value="<?php echo e($getProduct['name']); ?>">
                            </div>
                            <div class="col-md-2">
                                <label>Web_Id</label>
                            </div>
                            <div class="form-group col-md-10">
                                <input type="text" class="form-control" name="web_id" value="<?php echo e($getProduct['web_id']); ?>">
                            </div>
                            <div class="col-md-2">
                                <label>Price</label>
                            </div>
                            <div class="form-group col-md-10">
                                <input type="text" class="form-control" id="display" value="<?php echo e(number_format($getProduct['price'])); ?>">
                                <input hidden="" id="price" name="price" value="<?php echo e($getProduct['price']); ?>">
                            </div>
                            <div class="form-group col-md-3">
                            Status of product
                                </div>
                                <div class="form-group col-md-9">
                                    <div class="form-group col-md-12">
                                        <input type="radio" id="new" name="status" value="0" <?= ($getProduct["status"] == 0) ?  'checked'  : 
                                        '' ?> > New
                                    </div>
                                    <div class="form-group col-md-12">
                                        <input type="radio" id="sale" name="status" value="1" <?= ($getProduct["status"] == 1) ?  'checked'  : 
                                        '' ?> > Sale
                                        <input type="text" id="value_sale" name="sale"   disabled="" value="<?php echo e($getProduct['sale']); ?>">%
                                    </div>
                                </div>
                            <div class="col-md-2">
                                <label>Condition</label>
                            </div>
                            <div class="form-group col-md-10">
                                <input type="text" class="form-control" name="condition" value="<?php echo e($getProduct['condition']); ?>">
                            </div>
                            <div class="col-md-2">
                                <label>Category</label>
                            </div>
                            <div class="form-group col-md-10">
                                <select name="category" class="form-control form-control-line">
                                    <option value="">Please select</option>
                                    <?php $__currentLoopData = $Category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        <?php if($value['id'] == $getProduct['id_category']) echo "selected"?>     value="<?php echo e($key + 1); ?>"
                                    >
                                        <?php echo e($value['category']); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label>Brand</label>
                            </div>
                            <div class="form-group col-md-10">
                                <select name="brand" class="form-control form-control-line">
                                    <option value="">Please select</option>
                                    <?php $__currentLoopData = $Brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        <?php if($value['id'] == $getProduct['id_brand']) echo "selected"?>     value="<?php echo e($key + 1); ?>"
                                    >
                                        <?php echo e($value['brand']); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-12">
                                <input type="file" name="image[]" class="form-control" multiple>
                            </div>
                            <div class="col-sm-12">
                                <div class="view-product"> 
                                    <h4>Choose image you want to delete</h4>
                                    <?php $__currentLoopData = $getArrImage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="" style="position: relative; display: inline-block;">
                                            <img class="imageProduct" style="width: 100px ; height: 100px;" src="<?php echo e(URL::to('upload/product/'.Auth::user()->id.'/'.$value)); ?>" alt="">
                                            
                                            
                                            <input type="checkbox" name="image_delete[]" style="position: absolute; top: 3px; right: 3px;" value="<?php echo e($value); ?>">
                                        </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="form-group col-md-10">
                                <button style="margin-left: 0; margin-top: 50px;" type="submit" class="btn btn-default cart">Update your product</button>
                                <a class="btn btn-default" style="color: #fff; background: #989898; display: inline-block; margin: 50px 0 10px 0; border: 0 none; font-size: 15px; border-radius: 0" href="<?php echo e(url('/product/'.Auth::user()->id.'/list')); ?>">Cancel</a>
                            </div>
                        </form>
                        
                    </div>
                </div><!--/product-information--> 
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="text/javascript">
        document.getElementById("display").onblur =function (){    
            this.value = parseFloat(this.value.replace(/,/g, ""))
                            .toFixed()
                            .toString()
                            .replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            
            document.getElementById("price").value = this.value.replace(/,/g, "")
            
        }
        $('#sale').click(function()
        {
          $('#value_sale').removeAttr("disabled");
        });

        $('#new').click(function()
        {
          $('#value_sale').attr("disabled","disabled");
          $('#value_sale').attr("value","");
        });
        $(window).on('load', function() {
            if ($('#sale').is(':checked')) {
                $('#value_sale').removeAttr("disabled");
            };
        });
        
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/allen/Desktop/www/reactjs-laravel/laravel/laravel/resources/views/frontend/product/detail.blade.php ENDPATH**/ ?>