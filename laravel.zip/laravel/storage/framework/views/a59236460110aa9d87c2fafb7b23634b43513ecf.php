<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Home | E-Shopper</title>

    <link href="<?php echo e(asset('frontend/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('frontend/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('frontend/css/prettyPhoto.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('frontend/css/price-range.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('frontend/css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('frontend/css/main.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('frontend/css/responsive.css')); ?>" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="<?php echo e(asset('frontend/images/ico/favicon.ico')); ?>">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo e(asset('frontend/images/ico/apple-touch-icon-144-precomposed.png')); ?>">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo e(asset('frontend/images/ico/apple-touch-icon-114-precomposed.png')); ?>">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo e(asset('frontend/images/ico/apple-touch-icon-72-precomposed.png')); ?>">
    <link rel="apple-touch-icon-precomposed" href="<?php echo e(asset('frontend/images/ico/apple-touch-icon-57-precomposed.png')); ?>">
    <script type="text/javascript">
        window.Laravel = <?php echo json_encode([
            'baseUrl' => url('/'),
            'csrfToken' => csrf_token(),
        ]); ?>;
    </script>
</head><!--/head-->
    <body>
        <div id="app"></div>
        <script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>
        <script src="<?php echo e(asset('frontend/js/jquery.js')); ?>"></script>
        <script src="<?php echo e(asset('frontend/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('frontend/js/jquery.scrollUp.min.js')); ?>"></script>
        <script src="<?php echo e(asset('frontend/js/price-range.js')); ?>"></script>
        <script src="<?php echo e(asset('frontend/js/jquery.prettyPhoto.js')); ?>"></script>
        <script src="<?php echo e(asset('frontend/js/main.js')); ?>"></script>
    </body>
</html><?php /**PATH /Users/allen/Desktop/www/reactjs-laravel/laravel/laravel/resources/views/reactjs/welcome.blade.php ENDPATH**/ ?>