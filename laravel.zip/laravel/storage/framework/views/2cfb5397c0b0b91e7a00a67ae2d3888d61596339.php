 
<?php $__env->startSection('content'); ?>
 

<!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="page-breadcrumb">
        <div class="row">
            <div class="col-5 align-self-center">
                <h4 class="page-title"><?php echo e(__('admin.detailProduct')); ?></h4>
            </div>
            <div class="col-7 align-self-center">
                <div class="d-flex align-items-center justify-content-end">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(url('/admin/dashboard')); ?>">Home</a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('admin.detailProduct')); ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid">
        <div class="product-details"><!--product-details-->
            <div class="col-sm-12">
                <div class="view-product"> 
                    <?php $__currentLoopData = $getArrImage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href=""><img style="width: 100px ; height: 100px" src="<?php echo e(URL::to('upload/product/'.$getProduct['id_user'].'/'.$value)); ?>" alt=""></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="product-information"><!--/product-information-->
                    <div class="contact-form">
                        <h2 class="title text-center">Product Information</h2>
                        <form id="main-contact-form" class="contact-form row" name="contact-form" method="post">
                            <div class="col-md-2">
                                <label>Name</label>
                            </div>
                            <div class="form-group col-md-10">
                                <input type="text" class="form-control" readonly="" value="<?php echo e($getProduct['name']); ?>">
                            </div>
                            <div class="col-md-2">
                                <label>Web_Id</label>
                            </div>
                            <div class="form-group col-md-10">
                                <input type="text" class="form-control" readonly="" value="<?php echo e($getProduct['web_id']); ?>">
                            </div>
                            <div class="col-md-2">
                                <label>Price</label>
                            </div>
                            <div class="form-group col-md-10">
                                <input type="text" class="form-control" readonly="" value="<?php echo e(number_format($getProduct['price'])); ?>">
                            </div>
                            <div class="col-md-2">
                                <label>Condition</label>
                            </div>
                            <div class="form-group col-md-10">
                                <input type="text" class="form-control" readonly="" value="<?php echo e($getProduct['condition']); ?>">
                            </div>
                            <div class="col-md-2">
                                <label>Category</label>
                            </div>
                            <div class="form-group col-md-10">
                                <input type="text" class="form-control" readonly="" value="<?php echo e($Category['category']); ?>">
                            </div>
                            <div class="col-md-2">
                                <label>Brand</label>
                            </div>
                            <div class="form-group col-md-10">
                                <input type="text" class="form-control" readonly="" value="<?php echo e($Brand['brand']); ?>">
                            </div>
                        </form>
                        <form method="POST">
                            <?php echo csrf_field(); ?>
                            <?php if($getProduct['active'] == 0): ?>
                                <button style="margin-left: 0" type="submit" class="btn btn-fefault cart">
                                    <i class="mdi mdi-check"></i>
                                    Active this product
                                </button>
                            <?php else: ?>
                                <button style="margin-left: 0" type="submit" class="btn btn-fefault cart" disabled="">
                                    <i class="mdi mdi-check"></i>
                                    This Product is already active
                                </button>
                            <?php endif; ?>
                        </form>
                    </div>
                </div><!--/product-information-->
            </div>
        </div>
    </div>




    <script src="<?php echo e(asset('admin/dist/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/dist/js/price-range.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/dist/js/jquery.scrollUp.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/dist/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/dist/js/jquery.prettyPhoto.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/dist/js/main.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/baovic/Desktop/www/reactjs-laravel/laravel/laravel/resources/views/admin/product/detail.blade.php ENDPATH**/ ?>