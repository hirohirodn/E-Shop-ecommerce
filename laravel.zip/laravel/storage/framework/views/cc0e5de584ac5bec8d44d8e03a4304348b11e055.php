<?php $__env->startSection('content'); ?>


<!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="page-breadcrumb">
        <div class="row">
            <div class="col-5 align-self-center">
                <h4 class="page-title"><?php echo e(__('admin.listBrand')); ?></h4>
            </div>
            <div class="col-7 align-self-center">
                <div class="d-flex align-items-center justify-content-end">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(url('/admin/dashboard')); ?>">Home</a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('admin.listBrand')); ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid">
        <?php if(Session('success')): ?>

            <div class="alert alert-success alert-block">

                <button type="button" class="close" data-dismiss="alert">×</button>

                    <strong><?php echo e(Session('success')); ?></strong>

            </div>

        <?php endif; ?>
        <form method="POST">
            <?php echo csrf_field(); ?>

            <div class="form-group row">
                <label for="brand" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Brand')); ?></label>

                <div class="col-md-6">
                    <input id="country" type="text" class="form-control <?php if ($errors->has('brand')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('brand'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="brand" autofocus>

                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group row mb-0">
                <div class="col-md-8 offset-md-4">
                    <button type="submit" class="btn btn-primary">
                        <?php echo e(__('Add brand')); ?>

                    </button>

                </div>
            </div>
        </form>
        
        <br>
        <?php if(Session('deleted')): ?>
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong><?php echo e(Session('deleted')); ?></strong>
            </div>
        <?php endif; ?>
        

         <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="table-responsive">
                        <table class="table">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Brand</th>
                                    <th scope="col">Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $getAllBrand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($key + 1); ?></th>
                                    <td><?php echo e($value['brand']); ?></td>
                                    <td>
                                        <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(url('/admin/delete-brand/'.$value['id'])); ?>" aria-expanded="false">
                                            <i class="mdi mdi-delete">Delete</i>
                                        </a>
                                        
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/baovic/Desktop/www/reactjs-laravel/laravel/laravel/resources/views/admin/product/brand.blade.php ENDPATH**/ ?>