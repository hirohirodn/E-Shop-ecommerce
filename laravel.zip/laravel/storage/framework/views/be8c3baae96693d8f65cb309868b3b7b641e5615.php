<?php $__env->startSection('content'); ?>
	<!-- Container fluid  -->
    <!-- ============================================================== -->
    <div class="container-fluid">
        <?php if(Session('deleted')): ?>

            <div class="alert alert-success alert-block">

                <button type="button" class="close" data-dismiss="alert">×</button>

                    <strong><?php echo e(Session('deleted')); ?></strong>

            </div>

        <?php endif; ?>
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-12">
            	<h3>Your Product</h3>
                <div class="card">
                    <div class="table-responsive">
                        <table class="table">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Price</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Create at</th>
                                    <th scope="col">Action</th>
                                 </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $getAllProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($key + 1); ?></th>
                                    <td><?php echo e($value['name']); ?></td>
                                    <td><?php echo e(number_format($value['price'])); ?></td>
                                    <td><?php echo e($value['active'] == 1 ? 'Actived' : 'No active'); ?></td>
                                    <td><?php echo e(date('d-m-Y H:i:s', strtotime($value['created_at']))); ?></td>
                                    <td>
                                        <a class="sidebar-link  waves-dark sidebar-link" href="<?php echo e(url('/product/view/'.$value['id'])); ?>" aria-expanded="false">
                                            <i class="mdi mdi-eye">View</i>
                                        </a>
                                        <a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php echo e(url('/product/delete/'.$value['id'])); ?>" aria-expanded="false">
                                            <i class="mdi mdi-delete">Delete</i>
                                        </a>
                                        
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                       
                        

                    </div>
                </div>
            </div>
        </div>
    </div>
     <!-- end Container fluid  -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/allen/Desktop/www/reactjs-laravel/laravel/laravel/resources/views/frontend/product/list.blade.php ENDPATH**/ ?>