
<section id="slider"><!--slider-->
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<div id="slider-carousel" class="carousel slide" data-ride="carousel">
					<ol class="carousel-indicators">
						<?php $__currentLoopData = $getHighlightProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li data-target="#slider-carousel" data-slide-to="<?php echo e($key); ?>" class="<?php echo e($key==0 ? 'active' : ''); ?>"></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ol>
					
						<div class="carousel-inner">
							<?php $__currentLoopData = $getHighlightProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php
				                $getArrImage = json_decode($value['image'],true);
				            ?>
							<div class="item <?php echo e($key==0 ? 'active' : ''); ?>">
								<div class="col-sm-6">
									<h1><span><?php echo e($value['brand']['brand']); ?></span></h1>
									<h2><?php echo e($value['name']); ?></h2>
									<p><?php echo e($value['detail']); ?></p>
									<a href="<?php echo e(url('/detail-product/'.$value['id'])); ?>"><button type="button" class="btn btn-default get">Get it now</button></a>
								</div>
								<div class="col-sm-6">
									<img src="<?php echo e(URL::to('upload/product/'.$value['id_user'].'/larger_'.$getArrImage[0])); ?>" class="girl img-responsive" alt="" />
									<img src="<?php echo e(asset('frontend/images/home/pricing.png')); ?>"  class="pricing" alt="" />
								</div>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					
					<a href="#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev">
						<i class="fa fa-angle-left"></i>
					</a>
					<a href="#slider-carousel" class="right control-carousel hidden-xs" data-slide="next">
						<i class="fa fa-angle-right"></i>
					</a>
				</div>
				
			</div>
		</div>
	</div>
</section><!--/slider--><?php /**PATH /Users/baovic/Desktop/www/reactjs-laravel/laravel/laravel/resources/views/frontend/layouts/slide.blade.php ENDPATH**/ ?>