<div class="col-sm-3">
	<div class="left-sidebar">
		<h2>Category</h2>
		<div class="panel-group category-products" id="accordian"><!--category-productsr-->
			<?php $__currentLoopData = $getCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            	<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title"><a href="<?php echo e(url('/product/category/'.$value['id'])); ?>"><?php echo e($value['category']); ?></a></h4>
					</div>
				</div>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
			
		</div><!--/category-products-->
	
		<div class="brands_products"><!--brands_products-->
			<h2>Brands</h2>
			<div class="brands-name">
				<ul class="nav nav-pills nav-stacked">
					<?php $__currentLoopData = $getBrand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><a href="<?php echo e(url('/product/brand/'.$value['id'])); ?>"><?php echo e($value['brand']); ?></a></li>
            	
            		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		</div><!--/brands_products-->
		
		
		
		<div class="shipping text-center"><!--shipping-->
			<img src="<?php echo e(asset('frontend/images/home/shipping.jpg')); ?>" alt="" />
		</div><!--/shipping-->
	
	</div>
</div>

<?php /**PATH /Users/baovic/Desktop/www/reactjs-laravel/laravel/laravel/resources/views/frontend/layouts/menu-left.blade.php ENDPATH**/ ?>