<?php $__env->startSection('content'); ?>
	<?php if(!empty($result)): ?>
		<?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	            <?php
	                $getArrImage = json_decode($value['image'],true);
	            ?>
	            
	            <div class="col-sm-4">
	                <div class="product-image-wrapper">
	                    <div class="single-products">
	                            <div class="productinfo text-center">
	                                <img src="<?php echo e(URL::to('upload/product/'.$value['id_user'].'/larger_'.$getArrImage[0])); ?>" alt="" />
	                               

	                                <?php if($value['status'] == 0): ?>
	                                <span class="price"><?php echo e(number_format($value['price'])); ?></span>
	                                <?php else: ?>
	                                <span class="price_sale"><?php echo e(number_format($value['price'])); ?>$</span>
	                                <span class="price"><?php echo e(number_format($value['price']*(100-$value['sale'])/100)); ?>$</span>
	                                <?php endif; ?>
	                                
	                                <p><?php echo e($value['name']); ?></p>
	                                <a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
	                            </div>
	                            <div class="product-overlay">
	                                <div class="overlay-content">
	                                    <?php if($value['status'] == 0): ?>
	                                        <span class="price_overlay"><?php echo e(number_format($value['price'])); ?></span>
	                                    <?php else: ?>
	                                        <span class="price_sale_overlay"><?php echo e(number_format($value['price'])); ?>$</span>
	                                        <span class="price_overlay"><?php echo e(number_format($value['price']*(100-$value['sale'])/100)); ?>$</span>
	                                    <?php endif; ?>
	                                    <p><?php echo e($value['name']); ?></p>
	                                    <a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
	                                </div>
	                            </div>
	                            <img class="new" src="<?php echo e($value['status']==0 ? URL::to('upload/icon/new.png') : URL::to('upload/icon/sale.png')); ?>">
	                    </div>
	                    <div class="choose">
	                        <ul class="nav nav-pills nav-justified">
	                            <li><a href="<?php echo e(url('/detail-product/'.$value['id'])); ?>"><i class="fa fa-plus-square"></i>Product detail</a></li>
	                            <li><a href="#"><i class="fa fa-plus-square"></i>Add to compare</a></li>
	                        </ul>
	                    </div>
	                </div>
	            </div>
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    <?php elseif(!empty($result_price)): ?>
	    	<?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	            <?php
	                $getArrImage = json_decode($value['image'],true);
	            ?>
	            
	            <div class="col-sm-4">
	                <div class="product-image-wrapper">
	                    <div class="single-products">
	                            <div class="productinfo text-center">
	                                <img src="<?php echo e(URL::to('upload/product/'.$value['id_user'].'/larger_'.$getArrImage[0])); ?>" alt="" />
	                               

	                                <?php if($value['status'] == 0): ?>
	                                <span class="price"><?php echo e(number_format($value['price'])); ?></span>
	                                <?php else: ?>
	                                <span class="price_sale"><?php echo e(number_format($value['price'])); ?>$</span>
	                                <span class="price"><?php echo e(number_format($value['price']*(100-$value['sale'])/100)); ?>$</span>
	                                <?php endif; ?>
	                                
	                                <p><?php echo e($value['name']); ?></p>
	                                <a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
	                            </div>
	                            <div class="product-overlay">
	                                <div class="overlay-content">
	                                    <?php if($value['status'] == 0): ?>
	                                        <span class="price overlay"><?php echo e(number_format($value['price'])); ?></span>
	                                    <?php else: ?>
	                                        <span class="price_sale overlay"><?php echo e(number_format($value['price'])); ?>$</span>
	                                        <span class="price overlay"><?php echo e(number_format($value['price']*(100-$value['sale'])/100)); ?>$</span>
	                                    <?php endif; ?>
	                                    <p><?php echo e($value['name']); ?></p>
	                                    <a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
	                                </div>
	                            </div>
	                            <img class="new" src="<?php echo e($value['status']==0 ? URL::to('upload/icon/new.png') : URL::to('upload/icon/sale.png')); ?>">
	                    </div>
	                    <div class="choose">
	                        <ul class="nav nav-pills nav-justified">
	                            <li><a href="<?php echo e(url('/detail-product/'.$value['id'])); ?>"><i class="fa fa-plus-square"></i>Product detail</a></li>
	                            <li><a href="#"><i class="fa fa-plus-square"></i>Add to compare</a></li>
	                        </ul>
	                    </div>
	                </div>
	            </div>
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    <?php else: ?>
	    	<p style="margin-left: 150px; display: inline-block;">Can't found any product with your keyword."</p>
	    <?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/baovic/Desktop/www/reactjs-laravel/laravel/laravel/resources/views/frontend/product/result.blade.php ENDPATH**/ ?>